InfyOm Laravel Generator
==============================

[![Total Downloads](https://poser.pugx.org/infyomlabs/laravel-generator/downloads)](https://packagist.org/packages/infyomlabs/laravel-generator)
[![Monthly Downloads](https://poser.pugx.org/infyomlabs/laravel-generator/d/monthly)](https://packagist.org/packages/infyomlabs/laravel-generator)
[![Daily Downloads](https://poser.pugx.org/infyomlabs/laravel-generator/d/daily)](https://packagist.org/packages/infyomlabs/laravel-generator)
[![Latest Stable Version](https://poser.pugx.org/infyomlabs/laravel-generator/v/stable)](https://packagist.org/packages/infyomlabs/laravel-generator)
[![Latest Unstable Version](https://poser.pugx.org/infyomlabs/laravel-generator/v/unstable)](https://packagist.org/packages/infyomlabs/laravel-generator)
[![License](https://poser.pugx.org/infyomlabs/laravel-generator/license)](https://packagist.org/packages/infyomlabs/laravel-generator)

Documentation is located [here](http://labs.infyom.com/laravelgenerator)
