/**
 * Class {{ $config->modelNames->name }}Controller
 */
