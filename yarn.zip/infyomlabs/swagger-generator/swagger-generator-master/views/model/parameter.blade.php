     *      @OA\Parameter(
     *          name="{{ $fieldName }}",
     *          in="query",
     *          description="{{ $description }}",
     *          required=false,
     *          type="{{ $fieldType }}"
     *      )