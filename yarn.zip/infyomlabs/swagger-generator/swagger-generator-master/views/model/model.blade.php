/**
 * @OA\Schema(
 *      schema="{{ $config->modelNames->name }}",
 *      required={!! $requiredFields !!},
 {!! $properties !!}
 * )
 */