Core Bootstrap templates for InfyOm Laravel Generator
======================================================

## THIS PACKAGE IS DEPRECATED. USE [InfyOmLabs/adminlte-templates](https://github.com/InfyOmLabs/adminlte-templates) which is actively maintained.
