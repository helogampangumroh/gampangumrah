<?php
/**
* Language file for role section titles
*
*/

return [

    'create'			=> 'Create New Role',
    'edit' 				=> 'Edit Role',
    'management'	=> 'Manage Roles',
    'roles' => 'Roles',
    'roles_list' => 'Roles List',

];
