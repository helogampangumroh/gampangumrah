<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Delete Role',
    'body'            => 'Are you sure to delete this role? This operation is irreversible.',
    'cancel'        => 'Cancel',
    'confirm'        => 'Delete',

];
