<?php
/**
 * Language file for blog category table headings
 *
 */

return [

    'id' => 'Id',
    'title' => 'Title',
    'created_at' => 'Created at',
    'actions' => 'Actions',
    'update-blog' => 'update blog',
    'delete-blog' => 'delete blog'

];
