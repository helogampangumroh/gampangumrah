<?php

/**
* Language file for user delete modal
*
*/
return [

    'body'			=> 'Está seguro que quiere borrar este usuario? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',
    'title'         => 'Borrar Usuario',

];
