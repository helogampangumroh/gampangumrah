<?php

/**
 * Language file for delete modal
 *
 */
return [

    'title'         => 'Borrar registro',
    'body'			=> 'Está seguro que quiere borrar este registro? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',

];
