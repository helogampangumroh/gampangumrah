<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Nombre de la Categoría del Blog',
    'general' 		=> 'General',
];
