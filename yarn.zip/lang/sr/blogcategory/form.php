<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Naziv kategorije bloga',
    'general' 		=> 'Op�te',
];
