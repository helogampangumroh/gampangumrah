<?php
/**
* Language file for blog section titles
*
*/

return [

	'title'			=> 'Naziv',
    'create'			=> 'Kreiranje nove kategorije blogova',
    'edit' 				=> 'Izmjena kategorije bloga',
    'management'	=> 'Upravljanje kategorijama bloga',
    
];
