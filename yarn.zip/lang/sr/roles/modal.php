<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Brisanje grupe',
    'body'            => 'Da li ste sigurni da �elite obrisati ovu grupu? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'        => 'Odustani',
    'confirm'        => 'Obri�i',

];
