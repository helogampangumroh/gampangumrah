<?php
/**
* Language file for form fields for user account management
*
*/

return [

    'password'				=> 'Lozinka',
    'email'					=> 'Email',
    'newemail'				=> 'Novi email',
    'confirmemail'			=> 'Potvrda emaila',
    'firstname'				=> 'Ime',
    'lastname'				=> 'Prezime',
    'newpassword'			=> 'Nova lozinka',
    'website'				=> 'Website',
    'country'				=> 'Dr�ava',
    'gravataremail'			=> 'Gravatar email',
    'changegravatar'		=> 'Promjena avatara na Gravatar.com',
    'oldpassword'			=> 'Trenutna lozinka',
    'confirmpassword'		=> 'Ponovljena lozinka',

];
