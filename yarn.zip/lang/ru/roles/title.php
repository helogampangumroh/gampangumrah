<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Создать новую группу',
    'edit'                 => 'Редактирование группы',
    'management'    => 'Управление Группами пользователей',

];
