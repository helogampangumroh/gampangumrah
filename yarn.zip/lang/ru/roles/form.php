<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Наименование',
    'slug'          => 'Slug',
    'general'         => 'Основные',
    'permissions'    => 'Права доступа',

];
