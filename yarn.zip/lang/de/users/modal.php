<?php

/**
* Language file for user delete modal
*
*/
return [

    'body'			=> 'Sind Sie sicher, dass Sie diesen Benutzer löschen möchten? Dieser Vorgang kann nicht rückgängig gemacht werden.',
    'cancel'		=> 'Abrechen',
    'confirm'		=> 'Löschen',
    'title'         => 'Benutzer Löschen',

];
