<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Gruppe Löschen',
    'body'            => 'Sind Sie sicher, dass Sie diese Gruppe löschen möchten? Dieser Vorgang kann nicht rückgängig gemacht werden.',
    'cancel'        => 'Abbrechen',
    'confirm'        => 'Löschen',

];
