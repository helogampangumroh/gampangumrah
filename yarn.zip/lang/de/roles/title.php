<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Neue Gruppe erstellen',
    'edit'                 => 'Gruppe bearbeiten',
    'management'    => 'Gruppe verwalten',

];
