<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Id',
    'title'       => 'Titel',
    'comments'      => 'Anzahl der Kommentare',
    'created_at' => 'Erstellt am',
    'actions'	 => 'Aktionen',

];
