<?php

/**
* Language file for blog delete modal
*
*/
return [

    'body'		=> 'Sind Sie sicher, dass Sie diesen Blog löschen möchten? Dieser Vorgang kann nicht rückgängig gemacht werden.',
    'cancel'		=> 'Abbrechen',
    'confirm'		=> 'Löschen',
    'title'         => 'Blog löschen',

];
