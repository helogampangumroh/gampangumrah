<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Blog Kategorie Name',
    'general' 		=> 'Allgemein',
];
