<?php
/**
* Language file for blog section titles
*
*/

return [

	'title'			=> 'Titel',
    'create'			=> 'Neue Blog Kategorie erstellen',
    'edit' 				=> 'Bearbeiten der Blog Kategorie',
    'management'	=> 'Verwalten der Blog Kategorien',
    
];
