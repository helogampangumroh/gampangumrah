<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'Non',
    'noresults'  	=> 'Pas de résultats',
    'yes' 			=> 'Oui',
    'site_name'     => 'Nom de la page'

];
