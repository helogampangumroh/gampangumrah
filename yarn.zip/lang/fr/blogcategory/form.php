<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Nom de la catégorie du blog',
    'general' 		=> 'General',
];
