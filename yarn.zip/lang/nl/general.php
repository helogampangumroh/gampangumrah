<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'Nee',
    'noresults'  	=> 'Geen resultaten',
    'yes' 			=> 'Ja',
    'site_name'     => 'Pagina Naam'

];
