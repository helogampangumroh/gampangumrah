<?php

/**
* Language file for blog delete modal
*
*/
return [

    'body'			=> 'Weet je zeker dat je deze blog wilt verwijderen? Deze actie is niet terug te draaien.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Verwijder',
    'title'         => 'Verwijder Blog',

];
