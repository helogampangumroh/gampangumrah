<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Maak een nieuwe groep',
    'edit'                 => 'Wijzig groep',
    'management'    => 'Beheer groepen',

];
