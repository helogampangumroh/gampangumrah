<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Id',
    'name'       => 'Naam',
    'users'      => 'Aantal gebruikers',
    'created_at' => 'Gemaakt op',
    'actions'     => 'Acties',

];
