<?php
/**
* Language file for blog section titles
*
*/

return [

	'title'			=> 'Título',
    'create'			=> 'Criar nova Categoria de Blogue',
    'edit' 				=> 'Editar Categoria de Blogue',
    'management'	=> 'Gerenciar Categoria de Blogue',

];
