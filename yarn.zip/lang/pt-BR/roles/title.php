<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Criar Novo Grupo',
    'edit'                 => 'Editar Grupo',
    'management'    => 'Gerenciar Grupos',

];
