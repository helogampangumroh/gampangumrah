<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Apagar Grupo',
    'body'            => 'Tem certeza que quer apagar esse Grupo? Essa operação é irreversível.',
    'cancel'        => 'Cancelar',
    'confirm'        => 'Deletar',

];
