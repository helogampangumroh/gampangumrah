<?php

/**
* Language file for blog delete modal
*
*/
return [

    'body'			=> 'Tem certeza que quer apagar o artigo? Essa operação é irreversível.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Apagar',
    'title'         => 'Apagar Artigo',

];
